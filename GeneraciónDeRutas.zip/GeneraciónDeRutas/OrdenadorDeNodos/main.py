from collections import Counter
import networkx as nx
import matplotlib.pyplot as plt

# Ruta del archivo .txt

ruta_archivo = "...ruta.../grafo.txt"


# Leemos el contenido del archivo
with open(ruta_archivo, "r") as archivo:
    # Leemos todas las líneas y eliminamos los saltos de línea
    lista = [linea.strip() for linea in archivo.readlines()]

# Mostrar la lista original
print("Lista original:")
for item in lista:
    print(item)
print("\n")

# Contamos la cantidad de veces que aparece cada elemento
contador = Counter(lista)

# Creamos la nueva lista ordenada
lista_ordenada = []

# Añadimos los elementos en el orden que aparecen y repetimos según su conteo
for elem in lista:
    if elem in contador:
        lista_ordenada.extend([elem] * contador[elem])
        del contador[elem]  # Eliminamos el elemento para no procesarlo nuevamente

# Mostrar la lista ordenada
print("Lista ordenada:")
for item in lista_ordenada:
    print(item)
print("\n")

# Lista para almacenar las líneas únicas en el orden que aparecen
lineas_unicas = []
# Conjunto para rastrear las líneas ya vistas
vistas = set()

# Recorremos la lista ordenada y agregamos solo las líneas no repetidas
for linea in lista_ordenada:
    if linea not in vistas:
        lineas_unicas.append(linea)
        vistas.add(linea)

# Mostrar la lista con elementos repetidos eliminados
print("Lista sin elementos repetidos:")
for item in lineas_unicas:
    print(item)

# ---- Crear y visualizar el grafo ----

# Creamos un grafo
G = nx.Graph()

# Añadimos nodos y aristas al grafo usando la lista sin elementos repetidos
for linea in lineas_unicas:
    nodo1, nodo2 = linea.split('|')
    G.add_edge(nodo1, nodo2)

# Creamos un diccionario para posicionar los nodos según sus coordenadas
pos = {}
for nodo in G.nodes():
    x, y = map(int, nodo.split(','))
    pos[nodo] = (x, -y)  # Asignamos las coordenadas invirtiendo el eje Y

# Lista de colores de nodos
# Inicialmente, todos los nodos son de color azul
node_colors = ['skyblue'] * len(G.nodes())

# Obtener la lista de nodos del grafo para encontrar el primero y el último
nodos = list(G.nodes())

# Coloreamos el primer nodo de verde y el último de rojo
node_colors[nodos.index(nodos[0])] = 'green'  # Primer nodo
node_colors[nodos.index(nodos[-1])] = 'red'   # Último nodo

# ---- Algoritmo BFS para encontrar la ruta más corta ----

# Definir el nodo de inicio (verde) y el nodo de destino (rojo)
nodo_inicio = nodos[0]  # Primer nodo (verde)
nodo_destino = nodos[-1]  # Último nodo (rojo)

# Encontrar la ruta más corta usando BFS (por defecto)
ruta_mas_corta = nx.shortest_path(G, source=nodo_inicio, target=nodo_destino)

# Mostrar la ruta más corta
print(f"La ruta más corta desde {nodo_inicio} (verde) hasta {nodo_destino} (rojo) es:")
print(ruta_mas_corta)

# Obtener las aristas que forman parte de la ruta más corta
aristas_ruta_corta = list(zip(ruta_mas_corta, ruta_mas_corta[1:]))

# Dibujar el grafo resaltando las aristas de la ruta más corta en verde
edge_colors = ['green' if (u, v) in aristas_ruta_corta or (v, u) in aristas_ruta_corta else 'gray' for u, v in G.edges()]
edge_widths = [5 if (u, v) in aristas_ruta_corta or (v, u) in aristas_ruta_corta else 1 for u, v in G.edges()]

plt.figure(figsize=(10, 8))
nx.draw(G, pos, with_labels=True, node_color=node_colors, node_size=2000, font_size=10, font_weight='bold', edge_color=edge_colors, width=edge_widths)

# Mostrar el grafo con la ruta más corta resaltada
plt.title("Grafo con la Ruta más Corta Resaltada en Verde")
plt.show()

# from collections import Counter
# import networkx as nx
# import matplotlib.pyplot as plt
#
# # Ruta del archivo .txt
# ruta_archivo = "C:/Users/pereg/Documents/Proyectos Godot/Proyecto - Simulador de Robots v2/grafo.txt"
#
# # Leemos el contenido del archivo
# with open(ruta_archivo, "r") as archivo:
#     # Leemos todas las líneas y eliminamos los saltos de línea
#     lista = [linea.strip() for linea in archivo.readlines()]
#
# # Mostrar la lista original
# print("Lista original:")
# for item in lista:
#     print(item)
# print("\n")
#
# # Contamos la cantidad de veces que aparece cada elemento
# contador = Counter(lista)
#
# # Creamos la nueva lista ordenada
# lista_ordenada = []
#
# # Añadimos los elementos en el orden que aparecen y repetimos según su conteo
# for elem in lista:
#     if elem in contador:
#         lista_ordenada.extend([elem] * contador[elem])
#         del contador[elem]  # Eliminamos el elemento para no procesarlo nuevamente
#
# # Mostrar la lista ordenada
# print("Lista ordenada:")
# for item in lista_ordenada:
#     print(item)
# print("\n")
#
# # Lista para almacenar las líneas únicas en el orden que aparecen
# lineas_unicas = []
# # Conjunto para rastrear las líneas ya vistas
# vistas = set()
#
# # Recorremos la lista ordenada y agregamos solo las líneas no repetidas
# for linea in lista_ordenada:
#     if linea not in vistas:
#         lineas_unicas.append(linea)
#         vistas.add(linea)
#
# # Mostrar la lista con elementos repetidos eliminados
# print("Lista sin elementos repetidos:")
# for item in lineas_unicas:
#     print(item)
#
# # ---- Crear y visualizar el grafo ----
#
# # Creamos un grafo
# G = nx.Graph()
#
# # Añadimos nodos y aristas al grafo usando la lista sin elementos repetidos
# for linea in lineas_unicas:
#     nodo1, nodo2 = linea.split('|')
#     G.add_edge(nodo1, nodo2)
#
# # Creamos un diccionario para posicionar los nodos según sus coordenadas
# pos = {}
# for nodo in G.nodes():
#     x, y = map(int, nodo.split(','))
#     pos[nodo] = (x, -y)  # Asignamos las coordenadas invirtiendo el eje Y
#
# # Dibujamos el grafo usando las coordenadas reales como posiciones
# plt.figure(figsize=(10, 8))
# nx.draw(G, pos, with_labels=True, node_color='skyblue', node_size=2000, font_size=10, font_weight='bold', edge_color='gray')
#
# # Mostrar el grafo
# plt.title("Grafo de Coordenadas (Eje Y Invertido)")
# plt.show()

# //////
#
# from collections import Counter
#
# # Ruta del archivo .txt
# ruta_archivo = "C:/Users/pereg/Documents/Proyectos Godot/Proyecto - Simulador de Robots v2/grafo.txt"
#
# # Leemos el contenido del archivo
# with open(ruta_archivo, "r") as archivo:
#     # Leemos todas las líneas y eliminamos los saltos de línea
#     lista = [linea.strip() for linea in archivo.readlines()]
#
# # Mostrar la lista original
# print("Lista original:")
# for item in lista:
#     print(item)
# print("\n")
#
# # Contamos la cantidad de veces que aparece cada elemento
# contador = Counter(lista)
#
# # Creamos la nueva lista ordenada
# lista_ordenada = []
#
# # Añadimos los elementos en el orden que aparecen y repetimos según su conteo
# for elem in lista:
#     if elem in contador:
#         lista_ordenada.extend([elem] * contador[elem])
#         del contador[elem]  # Eliminamos el elemento para no procesarlo nuevamente
#
# # Mostrar la lista ordenada
# print("Lista ordenada:")
# for item in lista_ordenada:
#     print(item)
# print("\n")
#
# # Lista para almacenar las líneas únicas en el orden que aparecen
# lineas_unicas = []
# # Conjunto para rastrear las líneas ya vistas
# vistas = set()
#
# # Recorremos la lista ordenada y agregamos solo las líneas no repetidas
# for linea in lista_ordenada:
#     if linea not in vistas:
#         lineas_unicas.append(linea)
#         vistas.add(linea)
#
# # Mostrar la lista con elementos repetidos eliminados
# print("Lista sin elementos repetidos:")
# for item in lineas_unicas:
#     print(item)